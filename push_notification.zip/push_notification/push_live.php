<?php

define('API_ACCESS_KEY', 'AAAAAt3IeTM:APA91bH1KDJO70HPAXgpgJxG3TUjoeDc6DQ0oDCFq_tV2IkyRXSuPCwDbYPyT2JZGZ-VF6UtdgN7l8K5KsH5KKR1u8qcr9T1c74OBqwR5yRa-J88njCwLK-wN76Nhk6UGROrJA9mnYLy');

function sendMessageAndroid($target,$msg){
    //FCM api URL
    $url = 'https://fcm.googleapis.com/fcm/send';
    //api_key available in Firebase Console -> Project Settings -> CLOUD MESSAGING -> Server key
    $fields = array (
        'to' => $target,
        'notification' => array (
            "body" => $msg['body'],
            "title" => $msg['title'],
            "sound" => 'default'
        )
    );

    //header with content_type api key
    $headers = array(
    	'Content-Type:application/json',
      'Authorization:key='.API_ACCESS_KEY,
    );

    $response = Curl($url,json_encode($fields),$headers);
    return $response;
}

function sendMessageIOS($target,$msg)
{
    $apns_url = NULL;
    $apns_cert = NULL;
    //Apple server listening port
    $apns_port = 2195;

    // if ($pem_preference == "production") {
        $apns_url = 'gateway.push.apple.com';
        $apns_cert = __DIR__.'/apns-live_push.pem';
    // }
    //develop .pem
    // else {
    //     $apns_url = 'gateway.sandbox.push.apple.com';
    //     $apns_cert = __DIR__.'/devnew.pem';
    // }

    //Message IOS
    $badge = "0";
    $sound = 'default';

    $payload = array();
    $payload['aps'] = array(
        'alert' => array(
            "body"  => $msg['body'],
            "title" => $msg['title'],
        ),
        'badge' => intval($badge), 
        'sound' => $sound);
    $payload = json_encode($payload);

    $stream_context = stream_context_create();
    stream_context_set_option($stream_context, 'ssl', 'local_cert', $apns_cert);

    $apns = stream_socket_client('ssl://' . $apns_url . ':' . $apns_port, $error, $error_string, 60, STREAM_CLIENT_CONNECT|STREAM_CLIENT_PERSISTENT, $stream_context);
    //$msg = chr(0) . pack('n', 32) . pack('H*', $user_device_key) . pack('n', strlen($payload_info)) . $payload_info;
    $apns_message = chr(0) . pack('n', 32) . pack('H*', $target) . pack('n', strlen($payload)) . $payload;//chr(0) . chr(0) . chr(32) . pack('H*', str_replace(' ', '', $user_device_key)) . chr(0) . chr(strlen($payload_info)) . $payload_info;

    if ($apns) {
        $result = fwrite($apns, $apns_message);
    }
    @socket_close($apns);
    @fclose($apns);
    return $apns;
}
function Curl($url,$parameters = NULL,$headers = array())
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $parameters);
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}
$content = Curl('http://colette.edu.vn/?def=common&mod=apidevice&hf=1&key=6f1ddf5a96');
$data = json_decode($content,true);

foreach ($data as $key => $value) {
    // $content = $value['school'] . ': ';
    // $content .= $value['fullname'].'; ';
    // $content .= 'lớp:' . $value['class']. '; ';
    $content =  $value['content']. ';' ;
    if($value['content_vipham'])
    {
        $content .= 'vi phạm ' . $value['content_vipham'];
    }
    
    $mesage = array(
    'title' => $value['fullname'] . ' Lớp '. $value['class'] .' ' .$value['school'],
    'body'  => $value['content'],
    );
    
    $typeDevices = $value['devices'];
    echo $devicesId = $value['uid'];

    switch ($typeDevices) {
        case 'ios':
            $data = sendMessageIOS($devicesId,$mesage);
            break;
        case 'android':
            $data = sendMessageAndroid($devicesId,$mesage);
            break;
        default:
            break;
    }
    echo "  Done" . '</br>';
}
?>