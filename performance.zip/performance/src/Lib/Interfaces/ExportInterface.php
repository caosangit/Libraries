<?php namespace Performance\Lib\Interfaces;

interface ExportInterface
{
    public function export();
}