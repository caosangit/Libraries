<?php

class User extends Illuminate\Database\Eloquent\Model
{
    protected $table = 'user';

    public $timestamps = false;

}