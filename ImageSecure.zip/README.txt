Upload index.php, prism.css and prism.js to your webserver.
Then browse to index.php to get all the information you need.