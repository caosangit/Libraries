<?php
// GENERATE THE TOKEN, ADD AN EXPIRY TIMESTAMP
session_start();
$length = 32;
$_SESSION['token'] = substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $length); 
// 1 hour = 60 seconds * 60 minutes = 3600
$_SESSION['token-expire'] = time() + 3600;

//�THEN�CHECK FOR THE EXPIRY�ON REQUEST
if ($_SESSION['token']==$_POST['token']) {
  if (time() >= $_SESSION['token-expire']) {
    // EXPIRED - ASK USER TO RELOAD PAGE
  } else {
   // DO PROCESSING AS USUAL
  }
}
?>