$.ajax({
  url : "submit.php",
  data : {
    hello : "world",
    token : $('#token').val()
  }
});