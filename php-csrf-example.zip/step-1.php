<?php 
// RANDOM STRING CREDITS : https://www.thecodedeveloper.com/generate-random-alphanumeric-string-with-php/
session_start();
$length = 32;
$_SESSION['token'] = substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $length); 
?>