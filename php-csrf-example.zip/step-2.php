<?php
session_start();
?>
<form method="post" action="step-3.php">
  <p>The form that does absolutely nothing</p>
  <input type="text" name="hello" value="world"/>
  <input type="text" name="token" value="<?=$_SESSION['token']?>"/>
  <input type="submit" value="GO"/>
</form>