<?php 
session_start();
$length = 32;
$_SESSION['token'] = substr(base_convert(sha1(uniqid(mt_rand())), 16, 36), 0, $length); ?>
<input type="hidden" id="token" value="<?=$_SESSION['token']?>"/>
<div id="div-token" style="display:none"><?=$_SESSION['token']?></div>
<script>var token = <?=$_SESSION['token']?>;</script>