<?php
session_start();
if ($_SESSION['token']==$_POST['token']) {
  // VALID TOKEN PROVIDED - PROCEED WITH PROCESS
} else {
  // ERROR - INVALID TOKEN
}
?>