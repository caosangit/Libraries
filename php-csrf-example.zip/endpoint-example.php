<?php
// TOKEN CHECK
session_start();
if ($_SESSION['token']!=$_POST['token']) { die("INVALID TOKEN"); }

// PROCESS
switch ($_POST['req']) {
  case "add":
    // ADD NEW ACCOUNT
    break;

  case "edit":
    // UPDATE ACCOUNT
    break;

  case "del":
    // DELETE ACCOUNT
    break;
}
?>