import dep from './dep'
dep()
