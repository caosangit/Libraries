const dep = require('./dep')
dep()
